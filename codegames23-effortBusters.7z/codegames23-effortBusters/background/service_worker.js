/*
 * service worker
 */

import { Stats, StatsBuilder } from './stats.js';
import { HARBuilder } from './har.js';

const version = "1.0";

var tabs = {};
var gTabId;
let stats;
var logData = [];

// is devtools open
var openCount = 0;
var isDevToolsOpen = false;

// Always return true for async connections for chrome.runtime.onConnect.addListener
chrome.runtime.onConnect.addListener(function (port) {
    if (port.name == "devtools-page") {
        if (openCount == 0) {
            isDevToolsOpen = true
            // alert("DevTools window opening.");
        }
        openCount++;

        port.onDisconnect.addListener(function (port) {
            openCount--;
            if (openCount == 0) {
                isDevToolsOpen = false
            }
        });
    }
    return true;
});


// messages from popup.js
// Always return true for async connections for chrome.runtime.onConnect.addListener
chrome.runtime.onMessage.addListener(async function (request, sender, sendResponse) {
    let info = {}
    info.request = JSON.stringify(request)
    info.sender = JSON.stringify(sender)
    info.sendResponse = JSON.stringify(sendResponse)

    if (request.action === "getDevToolsStatus") {
        // response needs to be in JSON format
        sendResponse({ data: isDevToolsOpen })
    } else if (request.action === "getConsoleLog") {
        chrome.debugger.attach({ tabId: request.tabId }, version, onAttachConsoleLogs.bind(null, request.tabId));
    } else if (request.action === "downloadHARlog") {
        // chrome.debugger.detach({tabId: request.tabId});
        // chrome.storage.session.get("tabs", (items) => {
        //     let sessionTabs = items?.tabs ?? {};
        //     if (sessionTabs?.[request.tabId]) {
        if (tabs[request.tabId]) {
            const storage = chrome.storage;
            storage.session.get("issueId", function (result) {
                console.log(result.issueId);
                if(tabs[request.tabId]) {
                    try {
                attachFileToIssue(result.issueId, JSON.stringify(new HARBuilder().create([tabs?.[request.tabId]], `${request.host}.har`)));
                    }
                    catch(ex) {
                        console.error(ex);
                    }
                }
            });
            //console.log(JSON.stringify(new HARBuilder().create([tabs?.[request.tabId]], `${request.host}.har`)));
            tabs[request.tabId] = undefined;
        }
        // }
        // });


    } else if (request.action === "captureHARlog") {
        // onHARLogAttach(request.tabId);
        // console.log('capture HAR log....' + JSON.stringify(request));

        chrome.storage.session.get("tabs", (items) => {
            let sessionTabs = items?.tabs ?? {};
            // console.log("update sessionTabs: " + sessionTabs);
            if (request.enable) {
                let stats = new Stats();
                tabs[request.tabId] = stats;
                sessionTabs[request.tabId] = stats;
                // console.log("update sessionTabs 1: " + JSON.stringify(sessionTabs));
                chrome.debugger.attach({ tabId: request.tabId }, version,
                    onHARLogAttach.bind(null, request.tabId, tabs[request.tabId]));
            } else {
                sessionTabs[request.tabId] = undefined;
                // console.log("update sessionTabs 2: " + JSON.stringify(sessionTabs));
                chrome.debugger.detach({ tabId: request.tabId });
            }
            // console.log("update sessionTabs in session: " + JSON.stringify(sessionTabs));
            chrome.storage.session.set({ tabs: sessionTabs }, () => {
                console.log("sessionTabs in session updated. ");
            });
        });
    }
    return true;
});

/**
 * register a keyboard-shortcut handler/listener
 */
chrome.commands.onCommand.addListener(function (command, tab) {
    switch (command) {
        case 'duplicate-tab':
            duplicateTab();
            break;
        case 'screenshot-currentTab':
            screenshot(tab);
            break;
        // case 'console-log':
        //     fetchConsoleLog(tab);
        //     break;
        case 'har-log':
            createHARLog(tab);
            break;
        default:
            console.log(`Command ${command} not found`);
    }
});

// chrome.debugger.onEvent.addListener(function(debuggeeId, method, params) {
//     console.log(`...onEvent: ${debuggeeId}, method: ${method}`);
//     if (gTabId != debuggeeId.tabId) {
//         return;
//     }
//
//     chrome.storage.session.get("tabs", (items) => {
//         let sessionTabs = items?.tabs ?? {};
//
//         if (sessionTabs?.[gTabId]) {
//
//             StatsBuilder.processEvent(stats, {method, params});
//             if(method === "Network.loadingFinished") {
//                 chrome.debugger.sendCommand({ tabId: gTabId }, "Network.getResponseBody", { requestId: params.requestId }, (responseBodyParams) => {
//                     if(responseBodyParams){
//                         const {body, base64Encoded} = responseBodyParams;
//                         StatsBuilder.processEvent(stats, {method: 'Network.getResponseBody', params: {
//                                 requestId: params.requestId,
//                                 body,
//                                 base64Encoded
//                             }});
//                     }
//                 });
//             }
//         }
//     });
//     if(method === "Log.entryAdded") {
//         logData.push(params)
//     }
// });

// chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
//     chrome.desktopCapture.chooseDesktopMedia(
//         ["screen", "window"],
//         function(id) {
//             sendResponse({"id": id});
//         });
// });

/**
 * Gets the current active tab URL and opens a new tab with the same URL.
 */
function duplicateTab() {
    const query = { active: true, currentWindow: true };
    chrome.tabs.query(query, (tabs) => {
        chrome.tabs.create({ url: tabs[0].url, active: false });
    });
}

/**
 * Gets the current active tab URL and opens a new tab with the same URL.
 */
function screenshot() {
    console.log('...take a screenshot...');
    chrome.storage.sync.get((config) => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tab) => {
            chrome.tabs.captureVisibleTab(tab.windowId, { format: config.format }, (image) => {
                // image is base64
                console.log("try to save image: " + image)
                chrome.storage.local.set({ "image_": value }, () => {
                    console.log('Stored name: ' + value.name);
                });
            })
        });
    });
}


function createHARLog(tab) {
    // chrome.debugger.attach({tabId: tab.tabId}, version,
    //     onHARLogAttach.bind(null, tab.tabId));
}

/*
 * onAttach event for console-log
 */
function onAttachConsoleLogs(tabId) {
    gTabId = tabId;
    if (chrome.runtime.lastError) {
        return;
    }

    // use Log.enable and go from there
    chrome.debugger.sendCommand({ tabId: tabId }, "Log.enable");

    chrome.debugger.onEvent.addListener((debuggeeId, method, params) => {
        if (gTabId != debuggeeId.tabId) {
            return;
        }
        if (method === "Log.entryAdded") {
            logData.push(params)
        }
    });

    //chrome.debugger.onEvent.addListener(onEvent);

    setTimeout(() => {
        //let harBLOB = new Blob([JSON.stringify(logData)]);
        let base64Data = btoa(JSON.stringify(logData));

        // Construct a data URI with the base64-encoded data
        let dataUri = 'data:application/json;base64,' + base64Data;

        //let url = URL.createObjectURL(harBLOB);

        chrome.downloads.download({
            url: dataUri
        });

        // cleanup after downloading file
        chrome.debugger.sendCommand({ tabId: tabId }, "Log.disable");
        chrome.debugger.detach({ tabId: tabId });
        // Get the value stored with key "myKey"
        const storage = chrome.storage;

        var logsForPost = JSON.parse(JSON.stringify(logData));
        storage.session.get("issueId", function (result) {
            console.log(result.issueId);
            attachFileToIssue(result.issueId, logsForPost)
        });

        gTabId = undefined;
        logData = [];

    }, 1000);
}

function attachFileToIssue(issueId, logData) {

    const blob = new Blob([JSON.stringify(logData, null, 2)], { type: 'application/json' });

    // Create a new FormData object
    const formData = new FormData();

    // Append the Blob object to the FormData object with a filename
    formData.append('file', blob, 'data.json');

    fetch(`https://wondirection.atlassian.net/rest/api/3/issue/${issueId}/attachments`, {
        method: 'POST',
        headers: {
            'X-Atlassian-Token': 'nocheck',
            'Authorization': 'Basic c29uYWxpLmdob3RrdWxlMDhAZ21haWwuY29tOkFUQVRUM3hGZkdGMC01QkZxRV8xTmJPN3k3ejZMTURGczU1T3BXekJhOU84cG1Pb25qckhNVGI2WW1IR0pTTTR0Z0JSSm9mWjJBTjdZWkxBdmc4cVJvdEpqUWJXR2QzNTZ2MmxtNzlUR2ROd0hfTkxrUWZYaG5FVDR6cjVPSFE5TGw1T3JtZjZKNzlIWFQ5eENaQjRUaUpsczRPdHdyeHZ4dnJHMlN4bTlzamNFTHVOUDdrVnJXZz0yRDE4QjI5Mw==',
        },
        body: formData
    }).then(response => {
        if (response.ok) { return response; }
        else throw Error(`Server returned
		${response.status}: ${response.statusText}`)
    })
        .then(response => console.log(response.text()))
        .catch(err => console.log(err));
}


/**
 * onAttach event for HAR log
 * @param tabId
 */
function onHARLogAttach(tabId, stats) {
    gTabId = tabId;
    if (chrome.runtime.lastError) {
        return;
    }
    console.log("Debugger attached...");

    chrome.debugger.sendCommand({ tabId: gTabId }, "Network.enable");
    chrome.debugger.onEvent.addListener((debuggeeId, method, params) => {
        if (gTabId != debuggeeId.tabId) {
            return;
        }
        console.log("from HAR-related-event listener..." + method);
        StatsBuilder.processEvent(stats, { method, params });
        tabs[gTabId] = stats;
        if (method === "Network.loadingFinished") {
            chrome.debugger.sendCommand({ tabId: gTabId }, "Network.getResponseBody", { requestId: params.requestId }, (responseBodyParams) => {
                if (responseBodyParams) {
                    const { body, base64Encoded } = responseBodyParams;
                    StatsBuilder.processEvent(stats, {
                        method: 'Network.getResponseBody', params: {
                            requestId: params.requestId,
                            body,
                            base64Encoded
                        }
                    });
                }
            });
        }
    });

    // setTimeout(() => {
    //     chrome.tabs.get(gTabId, function(tab) {
    //         //let harBLOB = new Blob([JSON.stringify(logData)]);
    //         let base64Data = btoa(JSON.stringify(new HARBuilder().create(stats, new URL(tab.url).host + ".har")));
    //
    //         // Construct a data URI with the base64-encoded data
    //         let dataUri = 'data:application/json;base64,' + base64Data;
    //
    //         //let url = URL.createObjectURL(harBLOB);
    //
    //         chrome.downloads.download({
    //             url: dataUri
    //         });
    //
    //         // cleanup after downloading file
    //         chrome.debugger.sendCommand({tabId: tabId}, "Network.disable");
    //         chrome.debugger.detach({tabId: tabId});
    //     });
    // }, 1000);
}
