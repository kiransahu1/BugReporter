// Saves options to chrome.storage
const saveOptions = () => {
	const email = document.getElementById('email').value;
	const apiKey = document.getElementById('apiKey').value;
	const jiraBaseUrl = document.getElementById('jiraBaseUrl').value;

	chrome.storage.sync.set(
		{ email: email, apiKey: apiKey, jiraBaseUrl: jiraBaseUrl },
		() => {
			// Update status to let user know options were saved.
			const status = document.getElementById('status');
			status.textContent = 'Options saved.';
			setTimeout(() => {
				status.textContent = '';
			}, 750);
		}
	);
};

// Restores select box and checkbox state using the preferences
// stored in chrome.storage.
const restoreOptions = () => {
	chrome.storage.sync.get(
		{ email: '', apiKey: '', jiraBaseUrl: 'https://addison.atlassian.net/rest/api/3/' },
		(result) => {
			document.getElementById('email').value = result.email;
			document.getElementById('apiKey').value = result.apiKey;
			document.getElementById('jiraBaseUrl').value = result.jiraBaseUrl;
		}
	);
};

document.addEventListener('DOMContentLoaded', restoreOptions);
document.getElementById('save').addEventListener('click', saveOptions);